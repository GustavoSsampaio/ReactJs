import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root')); //create root vai criar uma raiz a partir do objeto(div )ONDE
root.render(
   <App />// o que vai acontecer dentro do root
);
